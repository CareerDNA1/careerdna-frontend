// src/Hooks/useSurveyEngine.js
import { useCallback, useMemo, useState, useEffect } from 'react';
import { fetchAiSummary } from '../utils/fetchAiSummary';
import { readProgress, writeProgress } from './useProgress';
import QUESTIONS from '../utils/questions';
import { calculateResults } from '../utils/calculateResults';
import scoreSubdimensions from '../utils/scoreSubdimensions';

function normalizeStatus(raw) {
  const s = String(raw || '').trim().toLowerCase();
  if (!s) return '';
  if (['school', 'gcse', 'a-level', 'alevel', 'sixth form', 'sixth-form'].includes(s)) return 'school';
  if (['undergrad', 'undergraduate', 'ug'].includes(s)) return 'undergraduate';
  if (['postgrad', 'postgraduate', 'pg', 'masters', 'master', 'msc', 'mba'].includes(s)) return 'postgraduate';
  if (['school', 'undergraduate', 'postgraduate'].includes(s)) return s;
  return '';
}

function coerceArray(x) {
  if (!x) return [];
  if (Array.isArray(x)) return x.filter(Boolean).map(String);
  return String(x)
    .split(',')
    .map(v => v.trim())
    .filter(Boolean);
}

export function useSurveyEngine(initialIntroResponses) {
  const persisted = readProgress();

  const [introResponsesState, setIntroResponses] = useState(
    persisted.introResponses || initialIntroResponses || {}
  );
  const [answers, setAnswers] = useState(persisted.answers || {});
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState('');
  const [analysisMeta, setAnalysisMeta] = useState(null);

  useEffect(() => {
    const p = readProgress();
    if (!p.nonce) {
      writeProgress({ nonce: `cdna-${Date.now()}-${Math.random().toString(36).slice(2, 8)}` });
    }
  }, []);

  useEffect(() => {
    writeProgress({ answers });
  }, [answers]);

  useEffect(() => {
    if (introResponsesState && typeof introResponsesState === 'object') {
      writeProgress({ introResponses: introResponsesState });
    }
  }, [introResponsesState]);

  // Safe scoring path: single source of truth.
  const archetypes = useMemo(() => {
    if (!answers || typeof answers !== 'object') return {};
    if (!Array.isArray(QUESTIONS)) return {};
    return calculateResults(answers, QUESTIONS);
  }, [answers]);

  const results = archetypes;

  const subdimensionScores = useMemo(() => {
    if (!answers || typeof answers !== 'object') return [];
    if (!Array.isArray(QUESTIONS)) return [];
    return scoreSubdimensions(answers, QUESTIONS);
  }, [answers]);

  useEffect(() => {
    try {
      sessionStorage.setItem('cdna_subdims_v1', JSON.stringify(subdimensionScores));
    } catch {}
  }, [subdimensionScores]);

  const generateSummary = useCallback(async () => {
    setLoading(true);
    try {
      let { age, status, schoolSubjects, uniSubject } = introResponsesState || {};

      const ageNum = typeof age === 'number' ? age : Number(age);
      let normStatus = normalizeStatus(status);

      if (!normStatus && Number.isFinite(ageNum)) {
        if (ageNum <= 18) normStatus = 'school';
        else normStatus = 'undergraduate';
      }

      const payload = {
        archetypes: archetypes || {},
        age: Number.isFinite(ageNum) ? ageNum : undefined,
        status: normStatus || undefined,
        ...(normStatus === 'school'
          ? { schoolSubjects: coerceArray(schoolSubjects) }
          : {
              uniSubject:
                typeof uniSubject === 'string'
                  ? uniSubject
                  : Array.isArray(uniSubject)
                  ? uniSubject[0]
                  : '',
            }),
        subdimensions: subdimensionScores,
      };

      const response = await fetchAiSummary(payload);

      if (typeof response === 'string') {
        setSummary(response || '');
        setAnalysisMeta(null);
      } else {
        setSummary(response?.summary || '');
        setAnalysisMeta(response?.analysisMeta || response?.sectionSignals || null);
      }
    } finally {
      setLoading(false);
    }
  }, [introResponsesState, archetypes, subdimensionScores]);

  return {
    introResponses: introResponsesState,
    setIntroResponses,
    answers,
    setAnswers,
    archetypes,
    results,
    subdimensionScores,
    loading,
    summary,
    setSummary,
    analysisMeta,
    setAnalysisMeta,
    generateSummary,

    // helpful passthroughs for pages that destructure these
    questions: QUESTIONS,
    state: { answers, questions: QUESTIONS, introResponses: introResponsesState },
  };
}

export default useSurveyEngine;
