// src/Components/Survey/DimensionsCarousel.js
import React, { useMemo, useState, useRef, useEffect, useCallback } from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, Tooltip, Legend);

/** Tweak these if you want a different size */
const VIEWPORT_DESKTOP_MAX = 820;   // px (try 780–860)
const VIEWPORT_WIDE_MAX    = 860;   // px (>=1280px screens)
const CHART_H_DESKTOP      = 240;   // px
const CHART_H_MOBILE       = 220;   // px

const truncate = (s, n = 26) => (s.length > n ? s.slice(0, n - 1) + "…" : s);
const normalizePct = (v) => (v <= 1 ? v * 100 : v);

const bg = (v) =>
  v >= 70 ? "rgba(0, 200, 150, 0.85)" : v >= 60 ? "rgba(75, 192, 192, 0.7)" : "rgba(200,200,200,.5)";
const border = (v) =>
  v >= 70 ? "rgba(0, 150, 120, 1)" : v >= 60 ? "rgba(75, 192, 192, 1)" : "rgba(160,160,160,1)";

/**
 * Props:
 *  - dimensions: array of 4 { label, key, subdimensions: [{key,label}] }
 *  - scores: map subdimKey|label -> percent (0..100 or 0..1)
 *  - maxPerDimension: how many bars (default 7)
 */
export default function DimensionsCarousel({ dimensions, scores, maxPerDimension = 7 }) {
  const [index, setIndex] = useState(0);
  const [isMobile, setIsMobile] = useState(false);
  const [maxW, setMaxW] = useState(VIEWPORT_DESKTOP_MAX);
  const trackRef = useRef(null);
  const touch = useRef({ x: 0, dragging: false });

  useEffect(() => {
    const onResize = () => {
      const w = window.innerWidth;
      setIsMobile(w < 900);
      setMaxW(w >= 1280 ? VIEWPORT_WIDE_MAX : w <= 768 ? undefined : VIEWPORT_DESKTOP_MAX);
    };
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // Canonical order
  const dims = useMemo(() => {
    const arr = Array.isArray(dimensions) ? dimensions : dimensions ? Object.values(dimensions) : [];
    const by = Object.fromEntries(arr.map((d) => [d.label, d]));
    return [
      by["Who You Are"] || arr[0],
      by["What You Love"] || arr[1],
      by["What Matters"] || arr[2],
      by["How You Work Best"] || arr[3],
    ].filter(Boolean);
  }, [dimensions]);

  const slides = useMemo(() => {
    return dims.map((dim) => {
      const rows = (dim?.subdimensions || []).map((sd) => {
        const raw =
          scores?.[sd.key] ?? scores?.[sd.label] ?? scores?.[sd.label?.toLowerCase?.()] ?? 0;
        const pct = Math.round(Math.max(0, Math.min(100, normalizePct(raw))));
        return { label: sd.label, value: pct };
      });
      rows.sort((a, b) => b.value - a.value);
      const picked = rows.slice(0, maxPerDimension);

      return {
        dimLabel: dim.label,
        data: {
          labels: picked.map((r) => r.label),
          datasets: [
            {
              label: "Score (%)",
              data: picked.map((r) => r.value),
              backgroundColor: picked.map((r) => bg(r.value)),
              borderColor: picked.map((r) => border(r.value)),
              borderWidth: 1.4,
              borderRadius: 5,
              categoryPercentage: 0.66,
              barPercentage: 0.92,
            },
          ],
        },
        options: {
          indexAxis: "y",
          responsive: true,
          maintainAspectRatio: false,
          layout: { padding: { right: 8, left: 2 } },
          plugins: { legend: { display: false }, tooltip: { enabled: true } },
          scales: {
            x: {
              min: 0,
              max: 100,
              grid: { color: "#eee" },
              ticks: {
                stepSize: 20,
                color: "#444",
                font: { size: isMobile ? 10 : 11 },
                callback: (val) => (val === 0 ? "" : `${val}%`),
              },
            },
            y: {
              grid: { display: false },
              ticks: {
                color: "#353535",
                font: { size: isMobile ? 10 : 11, weight: "600" },
                callback: function (v) {
                  const label = this.getLabelForValue ? this.getLabelForValue(v) : String(v);
                  return truncate(label, isMobile ? 22 : 26);
                },
              },
            },
          },
        },
      };
    });
  }, [dims, scores, isMobile, maxPerDimension]);

  const go = useCallback(
    (to) => setIndex(Math.max(0, Math.min(slides.length - 1, to))),
    [slides.length]
  );

  // touch swipe
  const onTouchStart = (e) => (touch.current = { x: e.touches[0].clientX, dragging: true });
  const onTouchMove = (e) => {
    if (!touch.current.dragging) return;
    const dx = e.touches[0].clientX - touch.current.x;
    if (trackRef.current) {
      trackRef.current.style.transition = "none";
      trackRef.current.style.transform = `translateX(calc(${-index * 100}% + ${dx}px))`;
    }
  };
  const onTouchEnd = (e) => {
    if (!touch.current.dragging) return;
    touch.current.dragging = false;
    const dx = e.changedTouches[0].clientX - touch.current.x;
    const th = 50;
    if (dx < -th) go(index + 1);
    else if (dx > th) go(index - 1);
    if (trackRef.current) {
      trackRef.current.style.transition = "transform 360ms ease";
      trackRef.current.style.transform = `translateX(${-index * 100}%)`;
    }
  };

  const viewportStyle = {
    width: "100%",
    maxWidth: maxW ? `${maxW}px` : "100%",
    margin: "0 auto",
    position: "relative",
    overflow: "hidden",
    borderRadius: 12,
  };

  return (
    <div style={viewportStyle} onTouchStart={onTouchStart} onTouchMove={onTouchMove} onTouchEnd={onTouchEnd}>
      <div
        ref={trackRef}
        style={{
          display: "flex",
          width: `${slides.length * 100}%`,
          transform: `translateX(${-index * 100}%)`,
          transition: "transform 360ms ease",
        }}
      >
        {slides.map((s, i) => (
          <div key={i} style={{ flex: "0 0 100%", padding: "6px 8px 10px", boxSizing: "border-box" }}>
            <h4 style={{ margin: "4px 0 8px 0", fontSize: 16, fontWeight: 700, textAlign: "left" }}>
              {s.dimLabel}
            </h4>
            <div style={{ width: "100%", height: isMobile ? CHART_H_MOBILE : CHART_H_DESKTOP }}>
              <Bar data={s.data} options={s.options} />
            </div>
          </div>
        ))}
      </div>

      {/* arrows */}
      <button
        aria-label="Previous"
        onClick={() => go(index - 1)}
        disabled={index === 0}
        style={arrowStyle("left", index === 0)}
      >
        ‹
      </button>
      <button
        aria-label="Next"
        onClick={() => go(index + 1)}
        disabled={index === slides.length - 1}
        style={arrowStyle("right", index === slides.length - 1)}
      >
        ›
      </button>

      {/* dots */}
      <div style={{ display: "flex", justifyContent: "center", marginTop: 10, gap: 8 }}>
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => go(i)}
            aria-label={`Go to slide ${i + 1}`}
            style={{
              width: 9,
              height: 9,
              borderRadius: 999,
              border: "none",
              background: i === index ? "#2f80ed" : "#cfd8e3",
              cursor: "pointer",
            }}
          />
        ))}
      </div>
    </div>
  );
}

function arrowStyle(side, disabled) {
  return {
    position: "absolute",
    top: "50%",
    [side]: 6,
    transform: "translateY(-50%)",
    width: 36,
    height: 36,
    borderRadius: 999,
    border: "1px solid #e1e1e1",
    background: disabled ? "rgba(255,255,255,0.7)" : "#fff",
    color: "#333",
    boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
    cursor: disabled ? "default" : "pointer",
    fontSize: 24,
    lineHeight: "32px",
    textAlign: "center",
    paddingBottom: 2,
  };
}
