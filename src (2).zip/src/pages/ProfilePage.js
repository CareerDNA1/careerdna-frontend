
import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AccountNavbar from '../Components/Common/AccountNavbar';
import { useAuth } from '../context/AuthContext';
import {
  listAssessmentRuns,
  rerunAssessmentWithOutputParameters,
} from '../utils/assessmentRuns';
import { getMyProfile } from '../utils/profile';
import IntroQuestions from '../Components/Survey/IntroQuestions';

const pageStyle = {
  minHeight: '100vh',
  background: 'linear-gradient(180deg, #f4f7fb 0%, #eef3f9 100%)',
  padding: '112px 20px 56px',
};

const shellStyle = {
  maxWidth: '1160px',
  margin: '0 auto',
};

const heroCardStyle = {
  background: '#ffffff',
  borderRadius: '24px',
  padding: '28px 32px',
  boxShadow: '0 16px 40px rgba(15, 23, 42, 0.08)',
  border: '1px solid rgba(47, 111, 237, 0.08)',
  marginBottom: '24px',
};

const sectionCardStyle = {
  background: '#ffffff',
  borderRadius: '24px',
  padding: '30px 36px',
  boxShadow: '0 16px 40px rgba(15, 23, 42, 0.08)',
  border: '1px solid rgba(47, 111, 237, 0.08)',
};

const primaryButtonStyle = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '12px 18px',
  borderRadius: '14px',
  border: 'none',
  background: '#2f6fed',
  color: '#fff',
  textDecoration: 'none',
  fontWeight: 700,
  cursor: 'pointer',
};

const secondaryButtonStyle = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '12px 18px',
  borderRadius: '14px',
  border: '1px solid #d7e3f4',
  background: '#f7faff',
  color: '#1f2a37',
  textDecoration: 'none',
  fontWeight: 700,
  cursor: 'pointer',
};

const ghostButtonStyle = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '12px 18px',
  borderRadius: '14px',
  border: '1px solid #d7e3f4',
  background: '#ffffff',
  color: '#1f2a37',
  textDecoration: 'none',
  fontWeight: 700,
  cursor: 'pointer',
};

const modalOverlayStyle = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(15, 23, 42, 0.55)',
  zIndex: 50000,
  overflowY: 'auto',
  padding: '96px 20px 40px',
};

const modalCardStyle = {
  maxWidth: '820px',
  margin: '0 auto',
  background: '#fff',
  borderRadius: '20px',
  boxShadow: '0 18px 50px rgba(0,0,0,0.24)',
  padding: '24px',
};

const defaultIntroResponses = {
  name: '',
  country: '',
  age: '',
  status: '',
  institution: '',
  schoolSubjects: [],
  uniSubject: '',
  schoolScope: '',
  uniNeed: '',
  planUniversity: '',
  currentActivity: '',
};

function buildInitialIntro(run) {
  const intro = run?.intro_answers_json || {};
  return {
    ...defaultIntroResponses,
    ...intro,
    schoolSubjects: Array.isArray(intro.schoolSubjects) ? intro.schoolSubjects : [],
  };
}

function statusLabel(value) {
  if (value === 'school') return 'At school';
  if (value === 'undergraduate') return 'At university';
  if (value === 'postgraduate') return 'Postgraduate student';
  if (value === 'other') return 'Other';
  return '—';
}

function nextStepLabel(run) {
  const intro = run?.intro_answers_json || {};
  const status = intro.status;

  const schoolMap = {
    gcse: 'Choose GCSEs',
    alevels: 'Choose A-Levels',
    apply_uni: 'Apply to university or college',
    apprenticeship: 'Explore apprenticeships',
    full_time_jobs: 'Explore full-time jobs',
    not_sure: 'Not sure yet',
  };

  const uniMap = {
    apply_postgrad: 'Apply for postgraduate study',
    apply_further_postgrad: 'Apply for further postgraduate study',
    explore_internships: 'Explore internships or placements',
    explore_full_time: 'Explore full-time roles',
    explore_specialisms: 'Explore other specialisms or subjects',
  };

  if (status === 'school' || status === 'other') return schoolMap[intro.schoolScope] || '—';
  if (status === 'undergraduate' || status === 'postgraduate') return uniMap[intro.uniNeed] || '—';
  return '—';
}

function subjectLabel(run) {
  const intro = run?.intro_answers_json || {};
  const status = intro.status;

  if (status === 'school') {
    const vals = Array.isArray(intro.schoolSubjects) ? intro.schoolSubjects : [];
    return vals.length ? vals.join(', ') : '—';
  }

  if (status === 'undergraduate' || status === 'postgraduate') {
    return intro.uniSubject || '—';
  }

  return '—';
}

function compactDate(value) {
  try {
    return new Date(value).toLocaleString();
  } catch {
    return '—';
  }
}

export default function ProfilePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profile, setProfile] = useState(null);
  const [runs, setRuns] = useState([]);
  const [loadingRuns, setLoadingRuns] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [editingRun, setEditingRun] = useState(null);
  const [editIntroResponses, setEditIntroResponses] = useState(defaultIntroResponses);
  const [rerunning, setRerunning] = useState(false);

  async function loadPageData() {
    setLoadingRuns(true);
    setErrorMsg('');
    const [profileData, runData] = await Promise.all([
      getMyProfile(),
      listAssessmentRuns(20),
    ]);
    setProfile(profileData || null);
    setRuns(runData || []);
    setLoadingRuns(false);
  }

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const [profileData, runData] = await Promise.all([
          getMyProfile(),
          listAssessmentRuns(20),
        ]);
        if (!cancelled) {
          setProfile(profileData || null);
          setRuns(runData || []);
        }
      } catch (err) {
        if (!cancelled) setErrorMsg(err.message || 'Failed to load profile.');
      } finally {
        if (!cancelled) setLoadingRuns(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const fullName = useMemo(() => {
    const first = profile?.first_name?.trim?.() || '';
    const last = profile?.last_name?.trim?.() || '';
    return [first, last].filter(Boolean).join(' ') || 'Not set yet';
  }, [profile]);

  const joined = useMemo(() => {
    if (!profile?.created_at) return '—';
    return compactDate(profile.created_at);
  }, [profile]);

  const openRun = (runId) => navigate(`/results/run/${runId}`);
  const handleRetake = () => navigate('/start');

  const openOutputParametersModal = (run) => {
    setEditingRun(run);
    setEditIntroResponses(buildInitialIntro(run));
  };

  const closeOutputParametersModal = () => {
    if (rerunning) return;
    setEditingRun(null);
    setEditIntroResponses(defaultIntroResponses);
  };

  const handleRerunOutput = async () => {
    if (!editingRun) return;
    try {
      setRerunning(true);
      setErrorMsg('');
      const newRun = await rerunAssessmentWithOutputParameters(editingRun, editIntroResponses);
      await loadPageData();
      setEditingRun(null);
      setEditIntroResponses(defaultIntroResponses);
      navigate(`/results/run/${newRun.id}`);
    } catch (err) {
      setErrorMsg(err.message || 'Failed to re-run output.');
    } finally {
      setRerunning(false);
    }
  };

  return (
    <div style={pageStyle}>
      <AccountNavbar menuOpen={menuOpen} setMenuOpen={setMenuOpen} />

      <div style={shellStyle}>
        <div style={heroCardStyle}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: '24px',
              alignItems: 'flex-start',
              flexWrap: 'wrap',
              marginBottom: '22px',
            }}
          >
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '8px',
                padding: '7px 12px',
                borderRadius: '999px',
                background: '#eef5ff',
                color: '#2f6fed',
                fontSize: '0.86rem',
                fontWeight: 700,
              }}
            >
              CareerDNA Account
            </div>

            <button type="button" style={secondaryButtonStyle} onClick={handleRetake}>
              Take Survey Again
            </button>
          </div>

          {errorMsg ? (
            <p style={{ color: '#d43c1c', marginTop: 0, marginBottom: '16px' }}>{errorMsg}</p>
          ) : null}

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
              gap: '16px',
            }}
          >
            {[
              { label: 'Full name', value: fullName, isEmail: false },
              { label: 'Email', value: profile?.email || user?.email || '—', isEmail: true },
              { label: 'Joined', value: joined, isEmail: false },
              { label: 'Saved runs', value: String(runs.length || 0), isEmail: false },
            ].map((item, idx) => (
              <div
                key={idx}
                style={{
                  padding: '18px 18px',
                  borderRadius: '18px',
                  background: '#f8fbff',
                  border: '1px solid #e3edf9',
                }}
              >
                <div
                  style={{
                    fontSize: '0.8rem',
                    textTransform: 'uppercase',
                    letterSpacing: '0.06em',
                    color: '#7a8798',
                    marginBottom: '8px',
                    fontWeight: 700,
                  }}
                >
                  {item.label}
                </div>
                <div
                  title={item.value}
                  style={{
                    fontSize: item.isEmail ? '0.95rem' : '1.02rem',
                    color: '#1f2a37',
                    fontWeight: 700,
                    whiteSpace: item.isEmail ? 'nowrap' : 'normal',
                    overflow: item.isEmail ? 'hidden' : 'visible',
                    textOverflow: item.isEmail ? 'ellipsis' : 'clip',
                  }}
                >
                  {item.value}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div style={sectionCardStyle}>
          <div style={{ marginBottom: '22px' }}>
            <h2
              style={{
                marginTop: 0,
                marginBottom: '10px',
                fontSize: '2rem',
                color: '#2f6fed',
                letterSpacing: '-0.02em',
              }}
            >
              Saved Results
            </h2>
            <p style={{ margin: 0, color: '#6b7788', fontSize: '1.03rem', maxWidth: '860px' }}>
              Review your saved CareerDNA runs, compare how your output changes over time, and launch a fresh assessment whenever you want.
            </p>
          </div>

          {loadingRuns ? (
            <p>Loading saved runs...</p>
          ) : runs.length === 0 ? (
            <div
              style={{
                border: '1px dashed #cfdceb',
                borderRadius: '20px',
                padding: '28px',
                background: '#f9fbfe',
              }}
            >
              <p style={{ color: '#54657b', marginTop: 0 }}>
                You do not have any saved CareerDNA results yet.
              </p>
              <button type="button" style={primaryButtonStyle} onClick={handleRetake}>
                Start your first assessment
              </button>
            </div>
          ) : (
            <div style={{ display: 'grid', gap: '16px' }}>
              {runs.map((run, idx) => (
                <div
                  key={run.id}
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'minmax(150px, 0.7fr) minmax(340px, 1.4fr) minmax(250px, 0.9fr)',
                    gap: '22px',
                    alignItems: 'center',
                    border: '1px solid #dbe7f4',
                    borderRadius: '22px',
                    padding: '22px 24px',
                    background: idx === 0 ? 'linear-gradient(180deg, #fbfdff 0%, #f6faff 100%)' : '#fff',
                  }}
                >
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                      <div style={{ fontSize: '1.06rem', fontWeight: 800, color: '#1f2a37' }}>
                        Run {runs.length - idx}
                      </div>
                      {idx === 0 ? (
                        <span
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            padding: '5px 10px',
                            borderRadius: '999px',
                            background: '#eef5ff',
                            color: '#2f6fed',
                            fontSize: '0.78rem',
                            fontWeight: 700,
                          }}
                        >
                          Latest
                        </span>
                      ) : null}
                    </div>
                    <div style={{ color: '#54657b', fontSize: '0.95rem' }}>
                      {compactDate(run.created_at)}
                    </div>
                  </div>

                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(2, minmax(130px, 1fr))',
                      gap: '14px 18px',
                    }}
                  >
                    <div>
                      <div
                        style={{
                          fontSize: '0.78rem',
                          color: '#7a8798',
                          marginBottom: '4px',
                          textTransform: 'uppercase',
                          letterSpacing: '0.05em',
                        }}
                      >
                        Age
                      </div>
                      <div style={{ fontWeight: 700, color: '#1f2a37' }}>{run.intro_answers_json?.age || '—'}</div>
                    </div>
                    <div>
                      <div
                        style={{
                          fontSize: '0.78rem',
                          color: '#7a8798',
                          marginBottom: '4px',
                          textTransform: 'uppercase',
                          letterSpacing: '0.05em',
                        }}
                      >
                        Current status
                      </div>
                      <div style={{ fontWeight: 700, color: '#1f2a37' }}>{statusLabel(run.intro_answers_json?.status)}</div>
                    </div>
                    <div>
                      <div
                        style={{
                          fontSize: '0.78rem',
                          color: '#7a8798',
                          marginBottom: '4px',
                          textTransform: 'uppercase',
                          letterSpacing: '0.05em',
                        }}
                      >
                        Next step
                      </div>
                      <div style={{ fontWeight: 700, color: '#1f2a37' }}>{nextStepLabel(run)}</div>
                    </div>
                    <div>
                      <div
                        style={{
                          fontSize: '0.78rem',
                          color: '#7a8798',
                          marginBottom: '4px',
                          textTransform: 'uppercase',
                          letterSpacing: '0.05em',
                        }}
                      >
                        Subjects of interest
                      </div>
                      <div style={{ fontWeight: 700, color: '#1f2a37' }}>{subjectLabel(run)}</div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    <button type="button" style={primaryButtonStyle} onClick={() => openRun(run.id)}>
                      Open Result
                    </button>
                    <button
                      type="button"
                      style={ghostButtonStyle}
                      onClick={() => openOutputParametersModal(run)}
                    >
                      Change Output Parameters
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {editingRun ? (
        <div style={modalOverlayStyle} onClick={closeOutputParametersModal}>
          <div style={modalCardStyle} onClick={(e) => e.stopPropagation()}>
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                gap: '16px',
                alignItems: 'flex-start',
                marginBottom: '16px',
              }}
            >
              <div>
                <h2 style={{ margin: 0, color: '#2f6fed', fontSize: '1.85rem' }}>Change Output Parameters</h2>
                <p style={{ marginTop: '10px', color: '#54657b' }}>
                  Update the output parameters for this saved run and then re-run the result using the same survey answers.
                </p>
              </div>
              <button type="button" style={secondaryButtonStyle} onClick={closeOutputParametersModal}>
                Close
              </button>
            </div>

            <IntroQuestions
              introResponses={editIntroResponses}
              setIntroResponses={setEditIntroResponses}
              onStartSurvey={handleRerunOutput}
              mode="edit"
              submitLabel="Re-run your CareerDNA Analysis"
            />

            {rerunning ? (
              <p style={{ marginTop: '16px', color: '#54657b' }}>Preparing your updated results...</p>
            ) : null}
          </div>
        </div>
      ) : null}
    </div>
  );
}
