// src/Components/Survey/ResultsComponent.js
import React, { useState, useEffect, useRef, useMemo } from 'react';
import './ResultsComponent.css';
import BarChart from './BarChart';
import { marked } from 'marked';
import Button from '../Common/Button';
import { FaBolt } from 'react-icons/fa';

import DimensionsCarousel from './DimensionsCarousel';
import DIMENSIONS from '../../utils/Dimensions';
import ClarityChart from './ClarityChart';

/* ---------- helpers ---------- */
const norm = (s) =>
  String(s || '')
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '')
    .trim();

const makeNameToKeyMap = (dimensionsArray) => {
  const map = Object.create(null);
  (Array.isArray(dimensionsArray) ? dimensionsArray : []).forEach((dim) => {
    (dim.subdimensions || []).forEach((sd) => {
      map[norm(sd.label)] = sd.key;
    });
  });
  return map;
};

const buildScoresForChartFromRows = (rows, dimensionsArray) => {
  const nameToKey = makeNameToKeyMap(dimensionsArray);
  const out = Object.create(null);
  (Array.isArray(rows) ? rows : []).forEach((r) => {
    const key = nameToKey[norm(r.name)];
    if (key) out[key] = Number(r.score_pct ?? 0);
  });
  return out;
};

function LoadingSpinnerWithProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const t = setInterval(() => {
      setProgress((p) => (p >= 99 ? p : p + Math.random() * 1.5));
    }, 290);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="analysis-loader">
      <div className="circular-loader">
        <svg className="progress-ring" width="100" height="100">
          <circle
            className="progress-ring__circle"
            stroke="#2f80ed"
            strokeWidth="8"
            fill="transparent"
            r="40"
            cx="50"
            cy="50"
            style={{
              strokeDasharray: 251,
              strokeDashoffset: 251 - (progress / 100) * 251,
            }}
          />
        </svg>
        <div className="progress-text">{Math.floor(progress)}%</div>
      </div>
      <p style={{ marginTop: 16, color: '#666', fontSize: 14 }}>
        Generating your personalised summary...
      </p>
    </div>
  );
}

function normaliseName(raw) {
  if (!raw || typeof raw !== 'string') return '';
  const trimmed = raw.trim().replace(/\s+/g, ' ');
  if (!trimmed) return '';
  const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1).toLowerCase() : '');
  return trimmed
    .split(' ')
    .map((t) => t.split('-').map(cap).join('-'))
    .join(' ');
}

/* ---- fixed version: remove ONLY the Subdimension Scores block ---- */


const SECTION_SIGNAL_KEYS = {
  Strengths: 'strengths',
  'Ideal Environments': 'environments',
  'Career Worlds': 'careerWorlds',
  'Role Suggestions': 'roles',
  'University Subject Suggestions': 'subjects',
};

function normalizeSignalTitle(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/&/g, 'and')
    .replace(/[^a-z0-9]+/g, '')
    .trim();
}

function extractSignalTitleFromListItem(li) {
  if (!li) return '';
  const strong = li.querySelector('strong');
  if (strong) return normalizeSignalTitle(strong.textContent.replace(/:\s*$/, ''));
  const raw = (li.textContent || '').split(':')[0] || '';
  return normalizeSignalTitle(raw);
}

function buildSignalMaps(analysisMeta) {
  const sections = analysisMeta?.sections || {};
  const out = {};
  Object.entries(sections).forEach(([key, rows]) => {
    out[key] = new Map(
      (Array.isArray(rows) ? rows : []).map((row) => [normalizeSignalTitle(row?.title), row])
    );
  });
  return out;
}

function decorateAnalysisSignals(root, analysisMeta) {
  if (!root) return;

  root.querySelectorAll('.cdna-item-signal').forEach((node) => node.remove());
  root.querySelectorAll('.cdna-signal-item').forEach((node) => node.classList.remove('cdna-signal-item'));

  if (!analysisMeta?.sections) return;

  const sectionMaps = buildSignalMaps(analysisMeta);
  const headings = Array.from(root.querySelectorAll('h2, h3'));

  headings.forEach((heading) => {
    const sectionKey = SECTION_SIGNAL_KEYS[String(heading.textContent || '').trim()];
    if (!sectionKey) return;

    let next = heading.nextElementSibling;
    while (next && !/^H[23]$/i.test(next.tagName)) {
      if (next.tagName === 'OL' || next.tagName === 'UL') break;
      next = next.nextElementSibling;
    }

    if (!next || (next.tagName !== 'OL' && next.tagName !== 'UL')) return;
    const titleMap = sectionMaps[sectionKey];
    if (!titleMap) return;

    Array.from(next.querySelectorAll(':scope > li')).forEach((li) => {
      const signal = titleMap.get(extractSignalTitleFromListItem(li));
      if (!signal) return;

      li.classList.add('cdna-signal-item');

      const signalEl = document.createElement('div');
      signalEl.className = 'cdna-item-signal';
      signalEl.innerHTML = `
        <span class="cdna-item-signal-label">${signal.signalLabel || 'Strong'}</span>
        <span class="cdna-item-signal-blocks" aria-hidden="true">
          ${Array.from({ length: 4 }, (_, idx) => `<span class="cdna-item-signal-block ${idx < Number(signal.signalBlocks || 0) ? 'is-filled' : ''}"></span>`).join('')}
        </span>
      `;

      li.appendChild(signalEl);
    });
  });
}

function stripSubdimensionSection(md = '') {
  if (!md) return md;
  const marker = '## Subdimension Scores';
  const idx = md.indexOf(marker);
  if (idx === -1) return md;

  const rest = md.slice(idx);
  const nextHeaderIdx = rest.indexOf('## ', marker.length);
  const before = md.slice(0, idx).trim();
  let after = '';
  if (nextHeaderIdx !== -1) {
    after = rest.slice(nextHeaderIdx).trim();
  }
  return [before, after].filter(Boolean).join('\n\n');
}

export default function ResultsComponent({
  results,
  initialAiSummary,
  fetchAiSummary,
  loadingSummary,
  chartRef,
  pdfRef,
  introName,
  onRetake,
  archetypes,
  summary,
  subdimensionRows,
  claritySummary, // 👈 NEW
  analysisMeta,
}) {
  const analysisRef = useRef(null);
  const markdownContentRef = useRef(null);

  const localChartsWrapperRef = useRef(null);
  const chartsWrapperRef = chartRef || localChartsWrapperRef;

  const computedResults = useMemo(() => {
    const primary =
      results && typeof results === 'object' && Object.keys(results).length > 0 ? results : null;
    const legacy =
      archetypes && typeof archetypes === 'object' && Object.keys(archetypes).length > 0
        ? archetypes
        : null;
    return primary || legacy || {};
  }, [results, archetypes]);

  const rawSummary = useMemo(() => {
    if (typeof initialAiSummary === 'string' && initialAiSummary.trim()) return initialAiSummary;
    if (typeof summary === 'string' && summary.trim()) return summary;
    return '';
  }, [initialAiSummary, summary]);

  const computedSummary = useMemo(() => {
    if (!rawSummary) return '';
    return stripSubdimensionSection(rawSummary);
  }, [rawSummary]);

  const displayName = useMemo(() => normaliseName(introName), [introName]);

  const handleRunAnalysis = () => {
    if (typeof fetchAiSummary === 'function') {
      fetchAiSummary();
      setTimeout(() => {
        analysisRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
    }
  };

  const hasResults = Object.keys(computedResults).length > 0;
  const canGenerate = typeof fetchAiSummary === 'function';



  useEffect(() => {
    if (!computedSummary || !markdownContentRef.current) return;
    const frame = window.requestAnimationFrame(() => {
      decorateAnalysisSignals(markdownContentRef.current, analysisMeta);
    });
    return () => window.cancelAnimationFrame(frame);
  }, [computedSummary, analysisMeta]);

  const scoresForChart = useMemo(() => {
    if (
      computedResults &&
      typeof computedResults.subdimensionScores === 'object' &&
      computedResults.subdimensionScores
    ) {
      return computedResults.subdimensionScores;
    }
    const rowCandidates =
      (Array.isArray(subdimensionRows) && subdimensionRows) ||
      (Array.isArray(computedResults?.subdimensions) && computedResults.subdimensions) ||
      (Array.isArray(computedResults?.subdimensionRows) && computedResults.subdimensionRows) ||
      [];
    if (rowCandidates.length > 0) {
      return buildScoresForChartFromRows(rowCandidates, DIMENSIONS);
    }
    return {};
  }, [computedResults, subdimensionRows]);

  return (
    <div id="results-root">
      {/* Intro */}
      <section className="results-container section-intro">
        <h1>Your Unique CareerDNA</h1>
        <p className="one-liner">
          {displayName && <strong>{displayName}</strong>}, CareerDNA combines insights from behavioural science and AI
          to help you understand what drives you and how you work, so you can make informed choices about your direction
          and development. There is no right or wrong profile. The results don’t measure ability or success. They simply describe
          your patterns of motivation and behaviour that make you who you are.
        </p>
        <div className="section-divider" />
      </section>

      <div ref={pdfRef} id="pdf-content">
        <div ref={chartsWrapperRef}>
          {/* Archetype Blend */}
          <section className="section">
            <div className="section-card section-card--full">
              <h2 style={{ color: '#2f80ed' }}>Your CareerDNA Type</h2>
              <p>
                Your type is based on seven archetypes that represent different ways people think, act and find motivation.
                Your results show how closely you relate to each one. Most people show stronger links with two or three types that together form a distinctive profile. Hover over each result to see a brief description of that archetype.
              </p>

              <div className="card-chart">
                {hasResults ? (
                  <BarChart archetypes={computedResults} />
                ) : (
                  <div className="analysis-box">
                    <p>No results found. Please complete the survey first.</p>
                  </div>
                )}
              </div>
            </div>
          </section>

          {/* DNA Dimensions */}
          {hasResults && (
            <section className="section">
              <div className="section-card section-card--full">
                <h2 style={{ color: '#2f80ed' }}>Your CareerDNA Dimensions</h2>
                <p>
                  Your CareerDNA is built around four lenses: <strong>Who You Are</strong>, <strong>What You Love</strong>, <strong>What Matters</strong>, and <strong>How You Work Best</strong>.
                  Together, they capture the main psychological dimensions that shape your motivation and fit, from personality traits and interests to values and working preferences.
                  Each lens includes specific subdimensions that show where your strengths naturally lie and what kind of environments bring out your best.
                </p>

                <div className="card-chart">
                  <div style={{ width: '820px', maxWidth: '100%', margin: '0 auto' }}>
                    <DimensionsCarousel
                      dimensions={DIMENSIONS}
                      scores={scoresForChart}
                      maxPerDimension={7}
                    />
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* Self-clarity section */}
          <section className="section">
            <div className="section-card section-card--full">
              <h2 style={{ color: '#2f80ed' }}>How well do you know yourself?</h2>
              <p>
                This estimates how clearly and consistently your answers describe you across the four CareerDNA dimensions.
                It looks at how decisive your answers are and how well your answers point in the same direction across related items.
                Higher % means a clearer self-view. It’s not a measure of ability but just a signal of confidence and consistency in how you see yourself today.
              </p>
              <div className="card-chart">
                <div style={{ width: '820px', maxWidth: '100%', margin: '0 auto' }}>
                  <ClarityChart minItems={1} claritySummary={claritySummary} />
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* CTA area */}
        {hasResults && canGenerate && !computedSummary && (
          <section className="results-cta">
            <h2>What do these results mean?</h2>
            <p>
              Your CareerDNA results are a starting point. The next step is a deeper analysis powered by our
              CareerDNA algorithm and AI engine that brings your scores together into a clear narrative,  diving into
              your strengths, ideal work environments, career fit areas, study subjects and potential roles, to help
              you make better choices with confidence.
            </p>

            {!loadingSummary && (
              <div className="results-actions">
                <Button type="primary" onClick={handleRunAnalysis}>
                  <FaBolt style={{ marginRight: 8 }} />
                  Run CareerDNA Analysis
                </Button>
              </div>
            )}
          </section>
        )}

        {(computedSummary || loadingSummary) && (
          <>
            <h2 className="analysis-title" ref={analysisRef}>
              🧠 Your CareerDNA Analysis
            </h2>

            <div className="analysis-box">
              {loadingSummary && !computedSummary ? (
                <LoadingSpinnerWithProgress />
              ) : computedSummary && computedSummary.startsWith('⚠️') ? (
                <p style={{ color: 'red' }}>{computedSummary}</p>
              ) : (
                computedSummary && (
                  <div
                    ref={markdownContentRef}
                    className="markdown-content"
                    dangerouslySetInnerHTML={{ __html: marked(computedSummary) }}
                  />
                )
              )}

            </div>
          </>
        )}
      </div>

      <div className="bottom-spacer" />
    </div>
  );
}
