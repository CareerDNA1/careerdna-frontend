import React from 'react';
import './SelectionInsightExplorer.css';
import {
  FaBrain,
  FaBullseye,
  FaCompass,
  FaLightbulb,
  FaTasks,
  FaPalette,
  FaUsers,
  FaCircle,
  FaStar,
} from 'react-icons/fa';

const ARCHETYPE_ICON_MAP = {
  creator: FaPalette,
  thinker: FaBrain,
  achiever: FaBullseye,
  visionary: FaLightbulb,
  explorer: FaCompass,
  organizer: FaTasks,
  connector: FaUsers,
};

function normalizeKey(value) {
  return String(value || '').trim().toLowerCase();
}

function tokenClass(state) {
  if (state === 'full') return 'fit-strong';
  if (state === 'mid') return 'fit-good';
  return 'fit-low';
}

function tokenOpacity(state) {
  if (state === 'full') return 1;
  if (state === 'mid') return 0.68;
  return 0.3;
}

function FitToken({ label, score, state, IconComponent, kind }) {
  return (
    <div className={`fit-token ${tokenClass(state)}`} title={`${label}: ${Math.round(score || 0)}%`}>
      <span
        className="fit-token__icon"
        style={{ opacity: tokenOpacity(state), filter: state === 'grey' ? 'grayscale(1)' : 'none' }}
        aria-hidden="true"
      >
        <IconComponent />
      </span>
      <span className="fit-token__text">
        <span className="fit-token__label">{label}</span>
        <span className="fit-token__score">{Math.round(score || 0)}%</span>
      </span>
      <span className={`fit-token__kind fit-token__kind--${kind}`}>{kind}</span>
    </div>
  );
}

function ItemFitCard({ item }) {
  const archetypes = Array.isArray(item?.archetypes) ? item.archetypes : [];
  const subdimensions = Array.isArray(item?.subdimensions) ? item.subdimensions : [];

  return (
    <article className="selection-fit-card">
      <div className="selection-fit-card__header">
        <div>
          <div className="selection-fit-card__eyebrow">{item?.type === 'role' ? 'Role insight' : 'Subject insight'}</div>
          <h3>{item?.title || 'Selected item'}</h3>
          {(item?.careerWorldTitle || item?.familyTitle) && (
            <p className="selection-fit-card__meta">
              {[item?.careerWorldTitle, item?.familyTitle].filter(Boolean).join(' · ')}
            </p>
          )}
        </div>
        {item?.signalLabel ? (
          <div className="selection-fit-card__signal">
            <span>{item.signalLabel}</span>
          </div>
        ) : null}
      </div>

      <div className="selection-fit-card__summary">
        <strong>{item?.strongSubdimensionCount || 0}</strong> of <strong>{item?.totalSubdimensionCount || 0}</strong> signature traits currently look strong in your profile.
      </div>

      {!!archetypes.length && (
        <div className="selection-fit-group">
          <h4>Signature archetypes</h4>
          <div className="selection-fit-grid">
            {archetypes.map((token) => {
              const IconComponent = ARCHETYPE_ICON_MAP[normalizeKey(token?.name)] || FaStar;
              return (
                <FitToken
                  key={`a-${item?.id}-${token?.name}`}
                  label={token?.name}
                  score={token?.userScore}
                  state={token?.state}
                  IconComponent={IconComponent}
                  kind="archetype"
                />
              );
            })}
          </div>
        </div>
      )}

      {!!subdimensions.length && (
        <div className="selection-fit-group">
          <h4>Signature subdimensions</h4>
          <div className="selection-fit-grid">
            {subdimensions.map((token) => (
              <FitToken
                key={`s-${item?.id}-${token?.name}`}
                label={token?.name}
                score={token?.userScore}
                state={token?.state}
                IconComponent={FaCircle}
                kind="subdimension"
              />
            ))}
          </div>
        </div>
      )}
    </article>
  );
}

export default function SelectionInsightExplorer({ insights, loading, error }) {
  if (loading) {
    return (
      <section className="selection-explorer">
        <div className="selection-explorer__intro">
          <h2>Discover more about your selections</h2>
          <p>Loading the deeper signature fit for the options you liked...</p>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="selection-explorer">
        <div className="selection-explorer__intro">
          <h2>Discover more about your selections</h2>
          <p className="selection-explorer__error">{error}</p>
        </div>
      </section>
    );
  }

  if (!Array.isArray(insights) || !insights.length) return null;

  return (
    <section className="selection-explorer">
      <div className="selection-explorer__intro">
        <h2>Discover more about your selections</h2>
        <p>
          Each card shows the signature archetypes and subdimensions most associated with that option.
          Stronger matches appear in full colour, while weaker matches stay faded or greyed out.
        </p>
      </div>

      <div className="selection-explorer__cards">
        {insights.map((item) => (
          <ItemFitCard key={item?.id || item?.title} item={item} />
        ))}
      </div>
    </section>
  );
}
