import React, { useEffect, useMemo, useState } from 'react';
import './SelectionInsightExplorer.css';
import {
  FaBrain,
  FaBullseye,
  FaCompass,
  FaLightbulb,
  FaTasks,
  FaPalette,
  FaUsers,
  FaStar,
  FaBriefcase,
} from 'react-icons/fa';

const ARCHETYPE_ICON_MAP = {
  creator: FaPalette,
  thinker: FaBrain,
  achiever: FaBullseye,
  visionary: FaLightbulb,
  explorer: FaCompass,
  organizer: FaTasks,
  connector: FaUsers,
};

function normalizeKey(value) {
  return String(value || '').trim().toLowerCase();
}

function sortSubdimensions(list = []) {
  const tierRank = { core: 0, signature: 0, fallback: 1, secondary: 2, modifier: 3 };
  return [...list].sort((a, b) => {
    const stateRank = { full: 0, mid: 1, grey: 2 };
    const stateDiff = (stateRank[a?.state] ?? 9) - (stateRank[b?.state] ?? 9);
    if (stateDiff !== 0) return stateDiff;
    const tierDiff = (tierRank[a?.tier] ?? 9) - (tierRank[b?.tier] ?? 9);
    if (tierDiff !== 0) return tierDiff;
    const scoreDiff = Number(b?.userScore || 0) - Number(a?.userScore || 0);
    if (scoreDiff !== 0) return scoreDiff;
    return String(a?.name || '').localeCompare(String(b?.name || ''));
  });
}

function sortArchetypes(list = []) {
  const stateRank = { full: 0, mid: 1, grey: 2 };
  return [...list].sort((a, b) => {
    const stateDiff = (stateRank[a?.state] ?? 9) - (stateRank[b?.state] ?? 9);
    if (stateDiff !== 0) return stateDiff;
    const scoreDiff = Number(b?.userScore || 0) - Number(a?.userScore || 0);
    if (scoreDiff !== 0) return scoreDiff;
    return String(a?.name || '').localeCompare(String(b?.name || ''));
  });
}

function getArchetypeBand(score = 0) {
  if (score >= 80) return 'Standout';
  if (score >= 72) return 'Very strong';
  if (score >= 65) return 'Strong';
  if (score >= 58) return 'Moderate';
  return 'Lower';
}

function getSubdimensionBand(score = 0) {
  if (score >= 70) return 'Standout';
  if (score >= 60) return 'Strong';
  if (score >= 50) return 'Moderate';
  return 'Lower';
}

function bandToVisualState(band = '') {
  if (band === 'Standout' || band === 'Very strong' || band === 'Strong') return 'full';
  if (band === 'Moderate') return 'mid';
  return 'grey';
}

function getAlignedTraitCount(values = []) {
  return values.filter((x) => getSubdimensionBand(Number(x?.userScore || 0)) !== 'Lower').length;
}

function getAlignedArchetypeCount(values = []) {
  return values.filter((x) => getArchetypeBand(Number(x?.userScore || 0)) !== 'Lower').length;
}

function buildMatchLabel(item = {}) {
  const raw = String(item?.signalLabel || '').trim();
  if (!raw) return '';
  return /match$/i.test(raw) ? raw : `${raw} match`;
}

function buildInterpretation(item = {}, coreSubdimensions = [], secondarySubdimensions = [], archetypes = []) {
  const title = item?.title || 'This option';
  const isPathway = Boolean(item?.isPathway || (Array.isArray(item?.roles) && item.roles.length));
  const alignedCore = coreSubdimensions
    .filter((x) => getSubdimensionBand(Number(x?.userScore || 0)) !== 'Lower')
    .map((x) => x?.name)
    .filter(Boolean);
  const alignedSecondary = secondarySubdimensions
    .filter((x) => getSubdimensionBand(Number(x?.userScore || 0)) !== 'Lower')
    .map((x) => x?.name)
    .filter(Boolean);
  const alignedArchetypes = archetypes
    .filter((x) => getArchetypeBand(Number(x?.userScore || 0)) !== 'Lower')
    .map((x) => x?.name)
    .filter(Boolean);

  if (isPathway && alignedCore.length >= 2) {
    return `${title} could suit you especially well where ${alignedCore.slice(0, 2).join(' and ')} already come through clearly in your profile, making this kind of pathway feel more natural and rewarding.`;
  }

  if (alignedCore.length >= 2) {
    return `${title} could suit you especially well where ${alignedCore.slice(0, 2).join(' and ')} already come through clearly in your profile.`;
  }

  if (alignedArchetypes.length >= 2) {
    return `${title} is supported most clearly by your ${alignedArchetypes.slice(0, 2).join(' and ')} pattern, with the strongest detail appearing in the traits below.`;
  }

  if (alignedSecondary.length) {
    return `${title} already shows some meaningful alignment, especially around ${alignedSecondary.slice(0, 2).join(' and ')}, even if the overall pattern is still more mixed than settled.`;
  }

  return `${title} is worth exploring further, with some parts of the signature already appearing more clearly than others.`;
}

function SignalBadge({ label, blocks = 0 }) {
  if (!label) return null;

  return (
    <div className="selection-detail-card__signal">
      <span className="selection-detail-card__signal-label">{label}</span>
      <span className="selection-detail-card__signal-bars" aria-hidden="true">
        {Array.from({ length: 4 }, (_, idx) => (
          <span
            key={idx}
            className={`selection-detail-card__signal-block ${idx < Number(blocks || 0) ? 'is-filled' : ''}`}
          />
        ))}
      </span>
    </div>
  );
}

function SelectionChip({ label, score, icon: Icon, kind = 'archetype' }) {
  const rounded = Math.round(Number(score || 0));
  const band = kind === 'archetype' ? getArchetypeBand(rounded) : getSubdimensionBand(rounded);
  const visual = bandToVisualState(band);

  return (
    <div className={`selection-chip selection-chip--${visual}`}>
      <span className="selection-chip__icon" aria-hidden="true">
        <Icon />
      </span>
      <div className="selection-chip__body">
        <div className="selection-chip__topline">
          <span className="selection-chip__label">{label}</span>
          <span className="selection-chip__band">{band}</span>
        </div>
        <div className="selection-chip__bar" aria-hidden="true">
          <span
            className="selection-chip__fill"
            style={{ width: `${Math.max(8, Math.min(100, rounded))}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function SubdimensionRow({ item }) {
  const score = Math.round(Number(item?.userScore || 0));
  const band = getSubdimensionBand(score);
  const visual = bandToVisualState(band);

  return (
    <div className={`subdimension-row subdimension-row--${visual}`}>
      <div className="subdimension-row__left">
        <span className="subdimension-row__dot" aria-hidden="true" />
        <div className="subdimension-row__copy">
          <span className="subdimension-row__name">{item?.name}</span>
          <div className="subdimension-row__meta-line">
            <span className="subdimension-row__band">{band}</span>
          </div>
        </div>
      </div>
      <div className="subdimension-row__right">
        <div className="subdimension-row__track" aria-hidden="true">
          <span className="subdimension-row__fill" style={{ width: `${Math.max(6, Math.min(100, score))}%` }} />
        </div>
      </div>
    </div>
  );
}

function SelectionListButton({ item, active, onClick }) {
  const matchLabel = buildMatchLabel(item);
  return (
    <button
      type="button"
      className={`selection-list-button ${active ? 'is-active' : ''}`}
      onClick={onClick}
    >
      <span className="selection-list-button__title">{item?.title}</span>
      <span className="selection-list-button__meta">{matchLabel || item?.signalLabel || ''}</span>
    </button>
  );
}

function SnapshotStat({ value, label }) {
  return (
    <div className="selection-snapshot__stat selection-snapshot__stat--compact">
      <span className="selection-snapshot__number">{value}</span>
      <span className="selection-snapshot__label">{label}</span>
    </div>
  );
}

function RoleItem({ item }) {
  return (
    <div className="pathway-role-item">
      <span className="pathway-role-item__icon" aria-hidden="true">
        <FaBriefcase />
      </span>
      <div className="pathway-role-item__copy">
        <span className="pathway-role-item__title">{item?.title}</span>
        {item?.entryLevelFit ? (
          <span className="pathway-role-item__meta">{item.entryLevelFit}</span>
        ) : null}
      </div>
    </div>
  );
}

function DetailPanel({ item }) {
  const archetypes = useMemo(
    () => sortArchetypes(Array.isArray(item?.archetypes) ? item.archetypes : []),
    [item]
  );
  const subdimensions = useMemo(() => sortSubdimensions(item?.subdimensions || []), [item]);
  const isPathway = Boolean(item?.isPathway || (Array.isArray(item?.roles) && item.roles.length));

  const coreSubdimensions = subdimensions.filter((x) => ['core', 'signature', 'fallback'].includes(String(x?.tier || '').toLowerCase()));
  const secondarySubdimensions = subdimensions.filter((x) => String(x?.tier || '').toLowerCase() === 'secondary');
  const tertiarySubdimensions = subdimensions.filter((x) => !['core', 'signature', 'fallback', 'secondary'].includes(String(x?.tier || '').toLowerCase()));
  const alignedTraitCount = getAlignedTraitCount(subdimensions);
  const totalTraitCount = Number(item?.totalSubdimensionCount || subdimensions.length || 0);
  const alignedArchetypeCount = getAlignedArchetypeCount(archetypes);
  const totalArchetypeCount = archetypes.length;
  const matchLabel = buildMatchLabel(item);
  const interpretation = buildInterpretation(item, coreSubdimensions, secondarySubdimensions, archetypes);

  return (
    <article className="selection-detail-card">
      <div className="selection-detail-card__header">
        <div>
          <div className="selection-detail-card__eyebrow">
            {isPathway ? 'Career pathway insight' : item?.type === 'role' ? 'Role insight' : 'Subject insight'}
          </div>
          <h3>{item?.title || 'Selected option'}</h3>
          {item?.careerWorldTitle ? (
            <p className="selection-detail-card__meta">{item.careerWorldTitle}</p>
          ) : null}
        </div>
        <div className="selection-detail-card__signal-wrap">
          <SignalBadge label={matchLabel || item?.signalLabel} blocks={item?.signalBlocks} />
        </div>
      </div>

      <div className="selection-snapshot">
        <div className="selection-snapshot__stats-grid">
          <SnapshotStat value={`${alignedArchetypeCount} / ${totalArchetypeCount}`} label="signature archetypes aligned" />
          <SnapshotStat value={`${alignedTraitCount} / ${totalTraitCount}`} label="signature traits aligned" />
        </div>
        <div className="selection-snapshot__divider" />
        <div className="selection-snapshot__copy">
          <div className="selection-snapshot__title">Why this could suit you</div>
          <p>{interpretation}</p>
        </div>
      </div>

      {!!archetypes.length && (
        <section className="selection-section-block">
          <div className="selection-section-block__header">
            <h4>Signature archetypes</h4>
            <p>The broader style this option tends to suit.</p>
          </div>
          <div className="selection-chip-grid">
            {archetypes.map((token) => {
              const IconComponent = ARCHETYPE_ICON_MAP[normalizeKey(token?.name)] || FaStar;
              return (
                <SelectionChip
                  key={`a-${item?.id}-${token?.name}`}
                  label={token?.name}
                  score={token?.userScore}
                  icon={IconComponent}
                  kind="archetype"
                />
              );
            })}
          </div>
        </section>
      )}

      {!!subdimensions.length && (
        <section className="selection-section-block">
          <div className="selection-section-block__header">
            <h4>Signature traits</h4>
            <p>The more specific traits that help explain this fit.</p>
          </div>

          {!!coreSubdimensions.length && (
            <div className="subdimension-group">
              <div className="subdimension-group__title">Core signature traits</div>
              <div className="subdimension-list">
                {coreSubdimensions.map((token) => (
                  <SubdimensionRow key={`core-${item?.id}-${token?.name}`} item={token} />
                ))}
              </div>
            </div>
          )}

          {!!secondarySubdimensions.length && (
            <div className="subdimension-group">
              <div className="subdimension-group__title">Secondary signature traits</div>
              <div className="subdimension-list">
                {secondarySubdimensions.map((token) => (
                  <SubdimensionRow key={`secondary-${item?.id}-${token?.name}`} item={token} />
                ))}
              </div>
            </div>
          )}

          {!!tertiarySubdimensions.length && (
            <div className="subdimension-group">
              <div className="subdimension-group__title">Additional supporting traits</div>
              <div className="subdimension-list">
                {tertiarySubdimensions.map((token) => (
                  <SubdimensionRow key={`other-${item?.id}-${token?.name}`} item={token} />
                ))}
              </div>
            </div>
          )}
        </section>
      )}

      {isPathway && Array.isArray(item?.roles) && item.roles.length > 0 && (
        <section className="selection-section-block">
          <div className="selection-section-block__header">
            <h4>Career roles within this pathway</h4>
            <p>These are example entry roles that sit inside this broader pathway.</p>
          </div>
          <div className="pathway-role-list">
            {item.roles.map((role) => (
              <RoleItem key={`${item?.id}-${role?.id || role?.title}`} item={role} />
            ))}
          </div>
        </section>
      )}
    </article>
  );
}

export default function SelectionInsightExplorer({ insights, loading, error }) {
  const validInsights = Array.isArray(insights) ? insights : [];
  const [activeId, setActiveId] = useState(validInsights[0]?.id || validInsights[0]?.title || '');

  useEffect(() => {
    const nextDefault = validInsights[0]?.id || validInsights[0]?.title || '';
    if (!validInsights.length) {
      setActiveId('');
      return;
    }
    const stillExists = validInsights.some((item) => (item?.id || item?.title) === activeId);
    if (!stillExists) setActiveId(nextDefault);
  }, [validInsights, activeId]);

  if (loading) {
    return (
      <section className="selection-explorer selection-explorer--loading">
        <div className="selection-explorer__intro">
          <h2>Discover more about your selections</h2>
          <p>Loading the deeper signature fit for the options you liked...</p>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="selection-explorer">
        <div className="selection-explorer__intro">
          <h2>Discover more about your selections</h2>
          <p className="selection-explorer__error">{error}</p>
        </div>
      </section>
    );
  }

  if (!validInsights.length) {
    return (
      <section className="selection-explorer">
        <div className="selection-explorer__intro">
          <h2>Discover more about your selections</h2>
          <p>No deeper insight is available for those selections yet.</p>
        </div>
      </section>
    );
  }

  const activeItem = validInsights.find((item) => (item?.id || item?.title) === activeId) || validInsights[0];
  const hasPathway = validInsights.some((item) => item?.isPathway || (Array.isArray(item?.roles) && item.roles.length));

  return (
    <section className="selection-explorer">
      <div className="selection-explorer__intro">
        <h2>Discover more about your selections</h2>
        <p>
          {hasPathway
            ? 'This view keeps the same overall match language as your main results, then shows the signature traits behind each pathway and the concrete roles inside it.'
            : 'This view uses the same overall match language as your main results, then shows the core and secondary signature traits behind each option in more detail.'}
        </p>
      </div>

      <div className="selection-explorer__layout">
        <aside className="selection-explorer__sidebar">
          <div className="selection-explorer__sidebar-title">Selected options</div>
          <div className="selection-explorer__sidebar-list">
            {validInsights.map((item) => {
              const key = item?.id || item?.title;
              return (
                <SelectionListButton
                  key={key}
                  item={item}
                  active={key === (activeItem?.id || activeItem?.title)}
                  onClick={() => setActiveId(key)}
                />
              );
            })}
          </div>
        </aside>

        <div className="selection-explorer__main">
          <DetailPanel item={activeItem} />
        </div>
      </div>
    </section>
  );
}
